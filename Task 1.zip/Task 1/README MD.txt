# Task 1: Exploring and Visualizing the Iris Dataset

## 🎯 Objective
To explore the Iris dataset and perform basic data inspection and visualization in order to understand data distributions, relationships between features, and potential outliers.

---

## 📦 Dataset
- **Source:** Built-in dataset from `seaborn`
- **Description:** Contains 150 samples from three species of Iris (Setosa, Versicolor, Virginica) with four features: sepal length, sepal width, petal length, and petal width.

---

## 🛠️ Tools & Libraries
- Python
- Jupyter Notebook
- pandas
- seaborn
- matplotlib

---

## 📊 Tasks Performed
- Loaded the Iris dataset using `seaborn.load_dataset()`.
- Inspected dataset shape, structure, and summary statistics.
- Visualized data using:
  - Pairplot (scatter matrix)
  - Histograms
  - Boxplots

---

## ✅ Key Insights
- Strong correlations observed between petal features and species.
- Sepal features are less separable between species.
- Few potential outliers identified in sepal width.

---

## 📁 Files Included
- `Task1_Iris_Exploration.ipynb` – Jupyter Notebook containing code and visualizations
- `README.md` – This file

---

## 📸 Sample Visualizations

> ![Sample Pairplot](https://seaborn.pydata.org/_images/seaborn-pairplot-1.png)  
*(Note: Replace with actual screenshot if desired)*

---

## 🧠 Learnings
- Gained hands-on experience in exploratory data analysis (EDA)
- Learned how to use seaborn/matplotlib to identify trends and patterns
